import re
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestClassifier  # 导入随机森林分类器
from sklearn.metrics import precision_score, recall_score, f1_score  # 导入评估指标
import jieba

# 加载训练数据
def load_training_data(positive_file, negative_file):
    def extract_reviews(file_path, label):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # 提取 <review> 标签内的文本
        reviews = re.findall(r'<review id="\d+">\s*(.*?)\s*</review>', content, re.S)
        return pd.DataFrame({'text': reviews, 'label': label})
    
    positive_df = extract_reviews(positive_file, 1)  # 正向评论
    negative_df = extract_reviews(negative_file, 0)  # 负向评论
    combined_df = pd.concat([positive_df, negative_df], ignore_index=True)
    print("训练数据加载完成:", combined_df.head())  # 打印加载的训练数据
    return combined_df

# 数据预处理
def preprocess_data(data, language="CN"):
    if language == "CN":  # 中文分词
        data['text'] = data['text'].apply(lambda x: ' '.join(jieba.cut(x)))
    return data

# 模型训练
def train_model(data):
    vectorizer = CountVectorizer()  # 词袋模型
    X = vectorizer.fit_transform(data['text'])
    y = data['label']
    model = RandomForestClassifier()  # 使用随机森林
    model.fit(X, y)
    return model, vectorizer

# 加载测试数据及其真实标签
def load_test_data_with_labels(file_path, labels_file):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # 提取 <review> 标签内的文本
    reviews = re.findall(r'<review id="\d+">\s*(.*?)\s*</review>', content, re.S)
    
    # 加载真实标签
    with open(labels_file, 'r', encoding='utf-8') as f:
        labels = [int(line.strip()) for line in f.readlines()]  # 假设标签为0或1
    
    print("测试数据加载完成:", reviews[:5])  # 打印前5条测试数据
    print("真实标签:", labels[:5])  # 打印前5个真实标签
    return reviews, labels

# 预测并保存结果
def predict_and_save(test_file, labels_file, model, vectorizer, team_name, run_tag, language, output_file):
    # 加载测试数据和真实标签
    test_data, y_true = load_test_data_with_labels(test_file, labels_file)
    # 中文分词
    if language == "CN":
        test_data = [' '.join(jieba.cut(review)) for review in test_data]
    # 特征提取
    X_test = vectorizer.transform(test_data)
    # 预测
    predictions = model.predict(X_test)
    
    # 计算指标
    precision = precision_score(y_true, predictions)
    recall = recall_score(y_true, predictions)
    f1 = f1_score(y_true, predictions)
    
    print(f"Precision: {precision}, Recall: {recall}, F1-Measure: {f1}")  # 输出指标

    # 保存结果
    with open(output_file, 'w', encoding='utf-8') as f:
        for i, polarity in enumerate(predictions):
            polarity_label = "positive" if polarity == 1 else "negative"
            f.write(f"{team_name} {run_tag} {i} {polarity_label}\n")
    print(f"测试结果已保存至 {output_file}")

# 主函数
if __name__ == "__main__":
    print("主函数开始执行")  # 确认主函数开始执行
    # 设置参数
    team_name = "TeamName"  # 替换为您的队名
    run_tag = "1"  # 替换为运行编号（1 或 2）

    # 加载中文训练数据
    train_data_cn = load_training_data("sample.positive.cn.txt", "sample.negative.cn.txt")
    train_data_cn = preprocess_data(train_data_cn, "CN")
    model_cn, vectorizer_cn = train_model(train_data_cn)

    # 加载英文训练数据
    train_data_en = load_training_data("sample.positive.en.txt", "sample.negative.en.txt")
    train_data_en = preprocess_data(train_data_en, "EN")
    model_en, vectorizer_en = train_model(train_data_en)

    # 对中文测试集预测
    predict_and_save(
        test_file="test.cn.txt",
        labels_file="test_labels.cn.txt",  # 真实标签文件
        model=model_cn,
        vectorizer=vectorizer_cn,
        team_name=team_name,
        run_tag=run_tag,
        language="CN",
        output_file=f"{team_name}_{run_tag}_CN.txt"
    )

    # 对英文测试集预测
    predict_and_save(
        test_file="test.en.txt",
        labels_file="test_labels.en.txt",  # 真实标签文件
        model=model_en,
        vectorizer=vectorizer_en,
        team_name=team_name,
        run_tag=run_tag,
        language="EN",
        output_file=f"{team_name}_{run_tag}_EN.txt"
    )