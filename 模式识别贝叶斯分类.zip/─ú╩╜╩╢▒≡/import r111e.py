import re

# 1. 加载真实标签并导出
def load_true_labels(label_file):
    true_labels = []
    with open(label_file, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
        reviews = re.findall(r'<review id="\d+"  label="(\d+)">', content)
        true_labels = [int(label) for label in reviews]
    
    # 导出真实标签到文件
    with open("extracted_true_labels.txt", "w", encoding="utf-8") as output_file:
        for label in true_labels:
            output_file.write(f"{label}\n")
    
    return true_labels

# 2. 加载预测结果并导出
def load_predictions(pred_file):
    predictions = []
    with open(pred_file, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 4:  # 格式：[TeamName] [RunTag] [ReviewID] [Polarity]
                polarity = 1 if parts[3].lower() == "positive" else 0
                predictions.append(polarity)
    
    # 导出预测结果到文件
    with open("extracted_predictions.txt", "w", encoding="utf-8") as output_file:
        for pred in predictions:
            output_file.write(f"{pred}\n")
    
    return predictions

# 3. 计算评估指标
def calculate_metrics(true_labels, predictions):
    TP = FP = TN = FN = 0

    for true, pred in zip(true_labels, predictions):
        if true == 1 and pred == 1:
            TP += 1
        elif true == 0 and pred == 1:
            FP += 1
        elif true == 0 and pred == 0:
            TN += 1
        elif true == 1 and pred == 0:
            FN += 1

    # 计算各项指标
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    precision_pos = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall_pos = TP / (TP + FN) if (TP + FN) > 0 else 0
    f1_pos = 2 * precision_pos * recall_pos / (precision_pos + recall_pos) if (precision_pos + recall_pos) > 0 else 0

    precision_neg = TN / (TN + FN) if (TN + FN) > 0 else 0
    recall_neg = TN / (TN + FP) if (TN + FP) > 0 else 0
    f1_neg = 2 * precision_neg * recall_neg / (precision_neg + recall_neg) if (precision_neg + recall_neg) > 0 else 0

    return {
        "accuracy": accuracy,
        "precision_pos": precision_pos,
        "recall_pos": recall_pos,
        "f1_pos": f1_pos,
        "precision_neg": precision_neg,
        "recall_neg": recall_neg,
        "f1_neg": f1_neg
    }

# 4. 主函数
if __name__ == "__main__":
    # 文件路径
    true_label_file = "test.label.en.txt"  # 替换为真实标签文件路径
    pred_file = "TeamName_1_EN.txt"  # 替换为预测结果文件路径

    # 加载数据
    true_labels = load_true_labels(true_label_file)
    predictions = load_predictions(pred_file)

    # 检查长度是否一致
    if len(true_labels) != len(predictions):
        raise ValueError("真实标签和预测结果数量不匹配，请检查文件内容！")

    # 计算指标
    metrics = calculate_metrics(true_labels, predictions)

    # 打印结果
    print("Evaluation Metrics:")
    print(f"Accuracy: {metrics['accuracy']:.4f}")
    print(f"Precision (Positive): {metrics['precision_pos']:.4f}")
    print(f"Recall (Positive): {metrics['recall_pos']:.4f}")
    print(f"F1-Score (Positive): {metrics['f1_pos']:.4f}")
    print(f"Precision (Negative): {metrics['precision_neg']:.4f}")
    print(f"Recall (Negative): {metrics['recall_neg']:.4f}")
    print(f"F1-Score (Negative): {metrics['f1_neg']:.4f}")
