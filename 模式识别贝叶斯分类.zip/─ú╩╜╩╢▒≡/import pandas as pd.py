import re
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import jieba

# 加载训练数据
def load_training_data(positive_file, negative_file):
    def extract_reviews(file_path, label):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # 提取 <review> 标签内的文本
        reviews = re.findall(r'<review id="\d+">\s*(.*?)\s*</review>', content, re.S)
        return pd.DataFrame({'text': reviews, 'label': label})
    
    positive_df = extract_reviews(positive_file, 1)  # 正向评论
    negative_df = extract_reviews(negative_file, 0)  # 负向评论
    return pd.concat([positive_df, negative_df], ignore_index=True)

# 数据预处理
def preprocess_data(data, language="CN"):
    if language == "CN":  # 中文分词
        data['text'] = data['text'].apply(lambda x: ' '.join(jieba.cut(x)))
    return data

# 模型训练
def train_model(data):
    vectorizer = CountVectorizer()  # 词袋模型
    X = vectorizer.fit_transform(data['text'])
    y = data['label']
    model = MultinomialNB()  # 朴素贝叶斯
    model.fit(X, y)
    return model, vectorizer

# 加载测试数据
def load_test_data(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # 提取 <review> 标签内的文本
    reviews = re.findall(r'<review id="\d+">\s*(.*?)\s*</review>', content, re.S)
    return reviews

# 预测并保存结果
def predict_and_save(test_file, model, vectorizer, team_name, run_tag, language, output_file):
    # 加载测试数据
    test_data = load_test_data(test_file)
    # 中文分词
    if language == "CN":
        test_data = [' '.join(jieba.cut(review)) for review in test_data]
    # 特征提取
    X_test = vectorizer.transform(test_data)
    # 预测
    predictions = model.predict(X_test)
    # 保存结果
    with open(output_file, 'w', encoding='utf-8') as f:
        for i, polarity in enumerate(predictions):
            polarity_label = "positive" if polarity == 1 else "negative"
            f.write(f"{team_name} {run_tag} {i} {polarity_label}\n")
    print(f"测试结果已保存至 {output_file}")

# 主函数
if __name__ == "__main__":
    # 设置参数
    team_name = "TeamName"  # 替换为您的队名
    run_tag = "1"  # 替换为运行编号（1 或 2）

    # 加载中文训练数据
    train_data_cn = load_training_data("sample.positive.cn.txt", "sample.negative.cn.txt")
    train_data_cn = preprocess_data(train_data_cn, "CN")
    model_cn, vectorizer_cn = train_model(train_data_cn)

    # 加载英文训练数据
    train_data_en = load_training_data("sample.positive.en.txt", "sample.negative.en.txt")
    train_data_en = preprocess_data(train_data_en, "EN")
    model_en, vectorizer_en = train_model(train_data_en)

    # 对中文测试集预测
    predict_and_save(
        test_file="test.cn.txt",
        model=model_cn,
        vectorizer=vectorizer_cn,
        team_name=team_name,
        run_tag=run_tag,
        language="CN",
        output_file=f"{team_name}_{run_tag}_CN.txt"
    )

    # 对英文测试集预测
    predict_and_save(
        test_file="test.en.txt",
        model=model_en,
        vectorizer=vectorizer_en,
        team_name=team_name,
        run_tag=run_tag,
        language="EN",
        output_file=f"{team_name}_{run_tag}_EN.txt"
    )
